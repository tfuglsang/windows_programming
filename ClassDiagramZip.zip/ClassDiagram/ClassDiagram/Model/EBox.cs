﻿namespace ClassDiagram.Model
{
    public enum EBox
    {
        Class,
        Abstract,
        Interface
    }
}